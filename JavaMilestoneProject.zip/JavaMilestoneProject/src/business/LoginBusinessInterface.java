package business;

import javax.ejb.Local;

import beans.User;

@Local
public interface LoginBusinessInterface {

	public String signIn(User user);
}
