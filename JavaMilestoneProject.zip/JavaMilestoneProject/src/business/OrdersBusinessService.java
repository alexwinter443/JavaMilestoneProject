package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface{
	
	List<Order> orders = new ArrayList<Order>();

	public OrdersBusinessService() {
		
		orders.add(new Order("0001","hand sanitizer slime", 20.3f, 24));
		orders.add(new Order("0002","mermaid tail", 35.3f, 22));
		orders.add(new Order("0003","movie prop money", 6.7f, 31));
		orders.add(new Order("0004","pet paint", 20.3f, 13));
		orders.add(new Order("0005","Drinking horn", 13.3f, 30));
		
	}
	

	@Override
	public void test() {
		System.out.println(" ------------- This Application is running OrdersBusinessService #1  ----------------");
		
	}

	@Override
	public List<Order> getOrders() {
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		
		this.orders = orders;
		
	}

}
