package business;

import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;
import beans.Product;

@Stateless
@Local(ProductBusinessInterface.class)
@Alternative
public class ProductBusinessService implements ProductBusinessInterface{

	@Override
	public void createProduct(List<Order> orders, Product product) {
		
		orders.add(new Order(product.getProductNo() , product.getProductName() , product.getPrice() , product.getQuantity()));
	}

}
