package business;

import java.util.List;

import javax.ejb.Local;

import beans.Order;
import beans.Product;

@Local
public interface ProductBusinessInterface {

	public void createProduct(List<Order> orders, Product product);
	
}
