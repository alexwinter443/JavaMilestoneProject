package business;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.faces.context.FacesContext;

import beans.User;

@Stateless
@Local(LoginBusinessInterface.class)
@Alternative
public class LoginBusinessService implements LoginBusinessInterface{

	@Override
	public String signIn(User user) {
		System.out.println("You clicked the submit button");
		System.out.println("The first name is " + user.getFirstName());
		System.out.println("The last name is " + user.getLastName());
		
		//put the user object into the post request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		// show the next page
		return "Response.xhtml";
	}

}
