package business;

import javax.ejb.Local;

import beans.User;

@Local
public interface RegisterBusinessInterface {

	public String register(User user);
	
}
