package business;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.faces.context.FacesContext;

import beans.User;

@Stateless
@Local(RegisterBusinessInterface.class)
@Alternative
public class RegisterBusinessService implements RegisterBusinessInterface{

	// register method
	@Override
	public String register(User user) {
		//put the user object into the post request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		// return successful register page
		return "RegistrationSuccessful.xhtml";
	}

}
