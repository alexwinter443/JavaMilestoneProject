/*
 * Alex vergara
 * Professor Jackson
 * Date: 2/14/2021
 * JSF Application
 * THIS IS MY OWN WORK
 * 
 */
package controllers;

import java.util.ArrayList;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import beans.Order;
import beans.Product;
import beans.User;
import business.LoginBusinessInterface;
import business.OrdersBusinessInterface;
import business.OrdersBusinessService;
import business.ProductBusinessInterface;
import business.ProductBusinessService;
import business.RegisterBusinessInterface;

@ManagedBean
public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	@Inject
	ProductBusinessInterface productService;
	
	@Inject
	LoginBusinessInterface loginService;
	
	@Inject
	RegisterBusinessInterface registerService;
	
	
	// 
	public String signIn(User user1) {
		
		// prints message to console to tell which business service is currently selected in the beans.xml file
		// as an alternative
		
		// show the user object data in the console log
		System.out.println("You clicked the submit button");
		System.out.println("The first name is " + user1.getFirstName());
		System.out.println("The last name is " + user1.getLastName());
		
		return loginService.signIn(user1);
		

	}
	
	public LoginBusinessInterface getLoginService() {
		return loginService;
	}
	
	
	
	public OrdersBusinessInterface getService() {
		return service;
		
	}
	
	
	public String createProduct(ArrayList<Order> orders) {
		FacesContext context = FacesContext.getCurrentInstance();
		
		Product product1 = context.getApplication().evaluateExpressionGet(context, "#{product}", Product.class);
		
		
		
		System.out.println("Product Number: " + product1.getProductNo());
		System.out.println("Product Name:  " + product1.getProductName());
		System.out.println("Product Price:  " + product1.getPrice() );
		System.out.println("Product Quantity:  " + product1.getQuantity() );
		
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("product", product1);
		
		productService.createProduct(orders, product1);
		
		return "Response.xhtml";
	}
	
	
	public ProductBusinessInterface getProductService() {
		return productService;
		
	}
	
	
	// REGISTER PAGE LINK
	public String registerPage()
	{
		return "Register.xhtml";
	}
	
	
	// Register Method
	public String register(User user) {
		return registerService.register(user);
	}
	
	
	public String home() {
		return "login-form.xhtml";
	}
	
	
	
	public RegisterBusinessInterface getRegisterService() {
		return registerService;
	}
}
